Name: Akash Kumar Dutta
The images are present in .png and .jpg files. The javascript and css used are used from external files. So in total there are not only 3 files, but 3+2+2=7 files.
Including this, there are 8 files.
Thanks.
